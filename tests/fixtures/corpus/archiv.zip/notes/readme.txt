Synthetic fixture archive; no copyrighted content.
